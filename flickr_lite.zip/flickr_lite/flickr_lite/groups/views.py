from django.shortcuts import render

from flickr_lite.permission import IsOwner
from .models import Group
from .serializers import GroupSerializer, GroupDeSerializer
from images.models import Image
from rest_framework import generics
from rest_framework.views import APIView
from django.contrib.auth.models import User

class GroupListView(generics.ListAPIView):
    permission_classes = [IsOwner]
    queryset = Image.objects.all()
    serializer_class = GroupDeSerializer
    def get_queryset(self):
        user = self.request.user
        return Group.objects.filter(owner=user)

class GroupRetriveView(generics.RetrieveAPIView):
    queryset = Group.objects.all()
    serializer_class = GroupDeSerializer
    permission_classes = [IsOwner]
