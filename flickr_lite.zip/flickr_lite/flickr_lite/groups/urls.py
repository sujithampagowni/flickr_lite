from django.conf.urls import url
from django.contrib import admin
from .views import GroupListView, GroupRetriveView

urlpatterns = [
    
    url(r'^$', GroupListView.as_view(), name='group-list'),
    # url(r'^mypost/$', PostMyListView.as_view(), name='post-my-list'),
    # url(r'^create/$', PostCreateView.as_view(), name='post-create'),
    url(r'^(?P<pk>\d+)/$', GroupRetriveView.as_view(), name='group-detail'),
    # url(r'^users/$', UserListView.as_view(), name='user-list'),

]