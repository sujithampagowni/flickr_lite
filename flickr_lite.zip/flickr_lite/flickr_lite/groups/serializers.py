from rest_framework import serializers
from .models import Group
from images.models import Image
from images.serializers import ImageListSerializer
from django.contrib.auth.models import User

class GroupSerializer(serializers.ModelSerializer):
    images = ImageListSerializer(many=True, read_only=True)
    class Meta:
        model = Group
        fields = ['title', 'owner', 'images', 'date_added']
    

class GroupDeSerializer(serializers.ModelSerializer):
    images = ImageListSerializer(many=True, read_only=True)
    class Meta:
        model = Group
        fields = ( 'id', 'url', 'title', 'owner', 'date_added', 'images')

    # def get_images(self, obj):
    #     _list=[]
    #     query_set = Image.objects.filter(group__title=obj.title)
    #     for i in enumerate(query_set):
    #         _list.append({ "id" : i[1].id, "title":i[1].title, "url":i[1].url})
    #     return _list
