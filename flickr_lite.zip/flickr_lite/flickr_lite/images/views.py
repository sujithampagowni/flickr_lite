from django.shortcuts import render

from flickr_lite.permission import IsOwner
from .models import Image
from .serializers import ImageSerializer, ImageListSerializer
from rest_framework import generics
from rest_framework.views import APIView
from django.contrib.auth.models import User

class ImageListView(generics.ListAPIView):
    permission_classes = [IsOwner]
    queryset = Image.objects.all()
    serializer_class = ImageListSerializer
    
    def get_queryset(self):
        user = self.request.user
        return Image.objects.filter(owner=user)

class ImageRetriveView(generics.RetrieveAPIView):
    queryset = Image.objects.all()
    serializer_class = ImageSerializer
    permission_classes = [IsOwner]
