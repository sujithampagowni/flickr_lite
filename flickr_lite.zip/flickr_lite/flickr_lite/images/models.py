from django.db import models
from django.conf import settings
from groups.models import Group

# Create your models here.
class Image(models.Model):
    title = models.CharField(max_length=30)
    image_id = models.CharField(max_length=10)
    group = models.ForeignKey(Group, related_name='images', on_delete=models.CASCADE)
    owner = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    image_url = models.CharField(max_length=30)
    # posted_on = models.CharField(max_length=10)

    def __str__(self):
        return self.title