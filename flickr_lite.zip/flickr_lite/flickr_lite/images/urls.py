from django.conf.urls import url
from django.contrib import admin
from .views import ImageListView, ImageRetriveView

urlpatterns = [
    url(r'^$', ImageListView.as_view(), name='image-list'),
    url(r'^(?P<pk>\d+)/$', ImageRetriveView.as_view(), name='image-detail'),
]
